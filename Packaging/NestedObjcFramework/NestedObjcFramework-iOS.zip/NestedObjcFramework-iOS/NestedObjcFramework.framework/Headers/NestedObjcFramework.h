//
//  NestedObjcFramework.h
//  NestedObjcFramework
//
//  Created by Abbey Jackson on 2019-05-02.
//  Copyright © 2019 abbeytest. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <NestedObjcFramework/NOFEntry.h>

//! Project version number for NestedObjcFramework.
FOUNDATION_EXPORT double NestedObjcFrameworkVersionNumber;

//! Project version string for NestedObjcFramework.
FOUNDATION_EXPORT const unsigned char NestedObjcFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NestedObjcFramework/PublicHeader.h>


