//
//  NestedCoreFramework.h
//  NestedCoreFramework
//
//  Created by Abbey Jackson on 2019-05-03.
//  Copyright © 2019 abbeytest. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <NestedCoreFramework/NCFEntry.h>

//! Project version number for NestedCoreFramework.
FOUNDATION_EXPORT double NestedCoreFrameworkVersionNumber;

//! Project version string for NestedCoreFramework.
FOUNDATION_EXPORT const unsigned char NestedCoreFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NestedCoreFramework/PublicHeader.h>


