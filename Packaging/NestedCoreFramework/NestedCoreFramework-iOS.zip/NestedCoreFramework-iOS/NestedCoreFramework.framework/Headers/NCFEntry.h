//
//  NCFEntry.h
//  NestedCoreFramework
//
//  Created by Abbey Jackson on 2019-05-03.
//  Copyright © 2019 abbeytest. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NCFEntry : NSObject
- (NSString *)coreLabel:(NSString *)prefix;
@end
