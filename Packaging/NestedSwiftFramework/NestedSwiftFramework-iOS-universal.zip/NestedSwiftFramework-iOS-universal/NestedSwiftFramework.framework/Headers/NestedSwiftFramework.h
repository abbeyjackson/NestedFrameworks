//
//  NestedSwiftFramework.h
//  NestedSwiftFramework
//
//  Created by Abbey Jackson on 2019-05-03.
//  Copyright © 2019 abbeytest. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NestedSwiftFramework.
FOUNDATION_EXPORT double NestedSwiftFrameworkVersionNumber;

//! Project version string for NestedSwiftFramework.
FOUNDATION_EXPORT const unsigned char NestedSwiftFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NestedSwiftFramework/PublicHeader.h>


