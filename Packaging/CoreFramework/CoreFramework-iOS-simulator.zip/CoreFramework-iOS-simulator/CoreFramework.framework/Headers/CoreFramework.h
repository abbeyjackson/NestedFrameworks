//
//  CoreFramework.h
//  CoreFramework
//
//  Created by Abbey Jackson on 2019-05-02.
//  Copyright © 2019 abbeytest. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreFramework/CFEntry.h>

//! Project version number for CoreFramework.
FOUNDATION_EXPORT double CoreFrameworkVersionNumber;

//! Project version string for CoreFramework.
FOUNDATION_EXPORT const unsigned char CoreFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CoreFramework/PublicHeader.h>


