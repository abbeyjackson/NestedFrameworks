//
//  ObjcFeatureFramework.h
//  ObjcFeatureFramework
//
//  Created by Abbey Jackson on 2019-05-03.
//  Copyright © 2019 abbeytest. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ObjcFeatureFramework/OFFEntry.h>

//! Project version number for ObjcFeatureFramework.
FOUNDATION_EXPORT double ObjcFeatureFrameworkVersionNumber;

//! Project version string for ObjcFeatureFramework.
FOUNDATION_EXPORT const unsigned char ObjcFeatureFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ObjcFeatureFramework/PublicHeader.h>


