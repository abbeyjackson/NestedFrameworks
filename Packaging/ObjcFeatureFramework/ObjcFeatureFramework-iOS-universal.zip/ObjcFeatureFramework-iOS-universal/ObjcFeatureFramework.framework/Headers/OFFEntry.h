//
//  OFFEntry.h
//  ObjcFeatureFramework
//
//  Created by Abbey Jackson on 2019-05-03.
//  Copyright © 2019 abbeytest. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OFFEntry : NSObject
- (NSString *)objcLabel;
@end

