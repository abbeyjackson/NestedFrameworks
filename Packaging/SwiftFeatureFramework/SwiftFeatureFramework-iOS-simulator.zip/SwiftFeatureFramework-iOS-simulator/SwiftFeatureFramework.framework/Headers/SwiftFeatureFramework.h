//
//  SwiftFeatureFramework.h
//  SwiftFeatureFramework
//
//  Created by Abbey Jackson on 2019-05-03.
//  Copyright © 2019 abbeytest. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftFeatureFramework.
FOUNDATION_EXPORT double SwiftFeatureFrameworkVersionNumber;

//! Project version string for SwiftFeatureFramework.
FOUNDATION_EXPORT const unsigned char SwiftFeatureFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftFeatureFramework/PublicHeader.h>


